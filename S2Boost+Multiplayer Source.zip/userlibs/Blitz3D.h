#pragma once

// Blitz notation: % for integer, # for floats, $ for ASCII strings and nothing for void

#define BBDECL extern "C" _declspec(dllexport)
#define BBCALL _stdcall