#pragma once
#include "Blitz3D.h"

// Stranded2BoostInit%():"_Stranded2BoostInit@0"
BBDECL int BBCALL Stranded2BoostInit();
// Stranded2BoostClear%():"_Stranded2BoostClear@0"
BBDECL int BBCALL Stranded2BoostClear();